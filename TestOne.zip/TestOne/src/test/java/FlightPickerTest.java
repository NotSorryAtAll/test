import io.github.bonigarcia.wdm.WebDriverManager;
import org.junit.*;
import org.openqa.selenium.WebDriver;

import java.time.Duration;

public class FlightPickerTest {

    private static WebDriver driver;

    @BeforeClass
    public static void globalBefore(){

        System.out.println("Hello Selenium!");
        driver = WebDriverManager.chromedriver().create();
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));

    }

    @Before
    public void before() {
        driver.get("https://blazedemo.com/index.php");
    }

    @Test
    public void checkTitle() {
        String pageTitle = driver.getTitle();
        Assert.assertEquals("BlazeDemo",pageTitle);

    }

    @Test
    public void boston() {
        FlightSearchPage flightSearchPage = new FlightSearchPage(driver);
        flightSearchPage.selectDepartureCity("Boston");
        flightSearchPage.clickFindFlightsButton();
        System.out.println("Selected flight!");
    }



    @Test
    public void portLand() {
        FlightSearchPage flightSearchPage = new FlightSearchPage(driver);
        flightSearchPage.selectDepartureCity("Portland");
        flightSearchPage.clickFindFlightsButton();
        System.out.println("Selected flight!");
    }


    @AfterClass
    public static void globalAfter() {
        driver.quit();
    }

}
