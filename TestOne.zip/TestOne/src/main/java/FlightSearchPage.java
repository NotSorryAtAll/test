import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class FlightSearchPage extends BasePage {


    public FlightSearchPage(WebDriver driver) {
        super(driver);
    }


    public void selectDepartureCity(String departureCity) {
        selectValueFromDropDown(By.cssSelector("select[name='fromPort']"),departureCity);
        Select flightFromDestination = new Select(driver.findElement(By.cssSelector("select[name='fromPort']")));
        flightFromDestination.selectByValue(departureCity);
    }

    public void clickFindFlightsButton() {
        WebElement selectFlight = driver.findElement(By.cssSelector("input[value=\"Find Flights\"]"));
        selectFlight.click();
    }

}
