import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.Select;

abstract public class BasePage {

    protected final WebDriver driver;

    public BasePage(WebDriver driver) {
        this.driver = driver;
    }

    public void selectValueFromDropDown(By selector, String dropDownValue) {
        Select dropDown = new Select(driver.findElement(selector));
        dropDown.selectByValue(dropDownValue);

    }
}
